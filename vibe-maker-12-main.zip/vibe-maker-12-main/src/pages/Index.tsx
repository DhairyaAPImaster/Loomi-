import { MusicApp } from "@/components/MusicApp";

const Index = () => {
  return <MusicApp />;
};

export default Index;
